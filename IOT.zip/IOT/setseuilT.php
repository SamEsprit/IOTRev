<?php
include 'IotConnexion.php';
$temp=$_GET["temp"];
$conn->query("UPDATE `seuil` SET `seuilT`= ".$temp." WHERE id=1;"); 

?>