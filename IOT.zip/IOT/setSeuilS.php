<?php
include 'IotConnexion.php';
$Son=$_GET["son"];
$conn->query("UPDATE `seuil` SET `seuilS`= ".$Son." WHERE id=1;"); 

?>