<?php
include 'IotConnexion.php';
$msg=$_GET["msg"];
$idcarte=$_GET["idcarte"];
if($idcarte == '1')
$conn->query("INSERT INTO `event`(`message`, `idcarte`) VALUES ('$msg','4')");
if($idcarte == '2')
$conn->query("INSERT INTO `event`(`message`, `idcarte`) VALUES ('$msg','3')"); 

?>