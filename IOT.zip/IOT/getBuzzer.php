<?php 
include 'IotConnexion.php';
$result=$conn->query("SELECT stateBuzzer FROM etat "); 
while($row=$result->fetch_array())
{
	 echo utf8_encode ($row['stateBuzzer']);
}

?>