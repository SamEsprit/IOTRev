<?php
include 'IotConnexion.php';
$result=$conn->query("SELECT LCD FROM seuil "); 
while($row=$result->fetch_array())
{
	 echo utf8_encode ($row['LCD']);
}

?>