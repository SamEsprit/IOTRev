<?php 
include 'IotConnexion.php';
$conn->query("UPDATE `etat` SET `stateBuzzer`=0 WHERE id=1;"); 

?>