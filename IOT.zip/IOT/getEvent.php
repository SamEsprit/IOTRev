<?php
include 'IotConnexion.php';
$result=$conn->query("SELECT message FROM event where `idcarte`=".$_GET['idcarte']." ORDER BY id DESC LIMIT 1 "); 
while($row=$result->fetch_array())
{
	 echo utf8_encode ($row['message']);
}

?>