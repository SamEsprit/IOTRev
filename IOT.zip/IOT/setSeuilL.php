<?php
include 'IotConnexion.php';
$light=$_GET["light"];
$conn->query("UPDATE `seuil` SET `seuilL`= ".$light." WHERE id=1;"); 

?>