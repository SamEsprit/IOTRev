<?php

include 'IotConnexion.php';
$temp=$_GET["temp"];
$son=$_GET["son"];
$light=$_GET["light"];

$sql="INSERT INTO `meteo`( `temp`, `light`, `son`) VALUES ('$temp','$son','$light')";

$conn->query($sql);





$conn->close();

?>