<?php 
include 'IotConnexion.php';
$result=$conn->query("SELECT state FROM etat "); 
while($row=$result->fetch_array())
{
	 echo utf8_encode ( $row['state'] );
}

?>