<?php
include 'IotConnexion.php';
$lcd=$_GET["lcd"];
$conn->query("UPDATE `seuil` SET `LCD`= '".$lcd."' WHERE id=1;"); 

?>