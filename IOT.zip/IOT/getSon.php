<?php 
include 'IotConnexion.php';
$result=$conn->query("SELECT son FROM meteo ORDER BY id DESC LIMIT 1"); 
while($row=$result->fetch_array())
{
	 echo $temp=$row['son'];
}

?>