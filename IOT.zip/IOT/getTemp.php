<?php 
include 'connexion.php';
$result=$conn->query("SELECT temp FROM meteo ORDER BY id DESC LIMIT 1"); 
while($row=$result->fetch_array())
{
	echo $temp=$row['temp'];
}

?>