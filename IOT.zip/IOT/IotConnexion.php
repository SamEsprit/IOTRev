<?php
$servername = "127.0.0.1";
$username = "thele461_sami";
$password = "Az140682";
$conn = new mysqli($servername,$username,$password,"thele461_IOT");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$conn->set_charset("utf8")

?>