<?php 
include 'IotConnexion.php';
$conn->query("UPDATE `etat` SET `state`=0 WHERE id=1;"); 
?>